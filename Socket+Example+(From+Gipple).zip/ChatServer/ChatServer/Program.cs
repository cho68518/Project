﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace ChatServer
{
    class ChatServer
    {
        public static ChatRoom Room = new ChatRoom();
        static void Main(string[] args)
        {
            TcpListener listener = null;
            bool Start_Service = false;
            try
            {
                //IPAddress ipAddress = Dns.GetHostEntry("localhost").AddressList[0];
                listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 8234);
                listener.Start();
                Console.WriteLine("1. 대기중입니다.");
                while (!Start_Service)
                {
                    Socket socket = listener.AcceptSocket();
                    Console.WriteLine("[+접속클라이언트]:" + socket.RemoteEndPoint);
                    if (socket.Connected)
                    {
                        ChatSupporter cs = new ChatSupporter(socket);
                        //ChatSupporter 스레드 생성 
                        Room.AddChatSupporter(cs);//ChatSupporter room에 저장
                    }
                }
            }
            catch { Console.WriteLine("서버 생성 도중 에러"); return; }

        }
    }
    public class ChatRoom
    {
        private ArrayList list = new ArrayList();
        public void AddChatSupporter(ChatSupporter client)
        {
            this.SendAll(client.ToString() + " 입장했습니다.");
            lock (list.SyncRoot) { list.Add(client); }
        }
        public void RemoveChatSupporter(ChatSupporter client)
        {
            lock (list.SyncRoot) { list.Remove(client); }
            this.SendAll(client.ToString() + " 퇴장했습니다.");
            Console.WriteLine("[-퇴장클라이언트]:" + client.ToString());
            client.CloseConnection();
        }
        public void SendAll(String msg)
        {
            lock (list.SyncRoot)
            {
                foreach (ChatSupporter client in list)
                {
                    client.Send(msg);
                }
            }
        }
    }//class
    public class ChatSupporter
    {
        private Socket m_socket;
        private NetworkStream m_stream;
        private StreamReader m_reader;
        private StreamWriter m_writer;
        private Thread reader;
        private bool flag;
        public ChatSupporter(Socket socket)
        {
            //네트워크 연결 및 스트림 생성
            this.m_socket = socket;
            try
            {
                this.m_stream = new NetworkStream(m_socket);//스트림얻기
                this.m_writer = new StreamWriter(m_stream);//출력스트림생성
                this.m_reader = new StreamReader(m_stream); //입력스트림생성 
                this.reader = new Thread(new ThreadStart(Receive));
                this.reader.Start(); //스레드 시작
            }
            catch { Console.WriteLine(m_socket + "에 에러 났습니다"); }

        }

        public void Receive()
        {
            //메시지 받기
            while (!flag)
            {
                try
                {
                    string message = this.m_reader.ReadLine();//메시지 수신
                    if (message != null)
                    {
                        ChatServer.Room.SendAll(message); //전체 메시지 전달
                    }
                }
                catch { flag = true; } //스레드 종료
            }
            ChatServer.Room.RemoveChatSupporter(this);
        }

        public void Send(string msg)
        {
            //메시지 보내기
            m_writer.WriteLine(msg);
            m_writer.Flush();

        }

        public void CloseConnection()
        {  
            //소켓 종료
            try
            {
                this.m_socket.Close();
            }
            catch { Console.WriteLine(m_socket.ToString() + "가 에러 났습니다"); }
            //소켓 닫기	
        }

        public override string ToString()
        {
            //정보출력
            return m_socket.RemoteEndPoint.ToString();
        }
    }//class

}
