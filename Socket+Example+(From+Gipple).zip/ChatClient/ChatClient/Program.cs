﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace ChatClient
{
    class ChatClient
    {
        private TcpClient client = new TcpClient();
        private NetworkStream m_stream = null;
        private StreamReader m_reader = null;
        private StreamWriter m_writer = null;
        private Thread reader = null, writer = null;
        private string nickname = null;
        private bool Start_Service = false;
        public ChatClient(string serverIp, int serverPort, string nickname)
        {
            //소켓을 생성하여 서버에 접속하는 부분
            try
            {
                this.nickname = nickname;//nickname 세팅
                client.Connect(serverIp, serverPort);//서버에 연결
                m_stream = client.GetStream();//스트림 얻기
                m_reader = new StreamReader(m_stream);//입력스트림 생성
                m_writer = new StreamWriter(m_stream);//출력 스트림 생성
                Console.WriteLine("1. 채팅 서버에 접속 성공!!!");
            }
            catch { Console.WriteLine("채팅 서버에 접속 실패!!!"); return; }
            this.reader = new Thread(new ThreadStart(Receive));
            this.writer = new Thread(new ThreadStart(Send));
            this.reader.Start(); //메시지 읽어오는 스레드 시작
            this.writer.Start(); //메시지 보내는 스레드 시작
        }

        public void Receive()
        {
            //메시지를 받는 부분
            Console.WriteLine("2. Reading을 위한 스레드 부분 실행!!!");
            while (!Start_Service)
            {
                try
                {
                    string message = this.m_reader.ReadLine();
                    if (message != null)
                    {
                        Console.WriteLine(message);
                    }
                }
                catch { Start_Service = false; }
            }
            m_reader.Close();
            m_writer.Close();
            m_stream.Close();
            client.Close();
        }

        public void Send()
        {
            //메시지를 보내는 부분
            Console.WriteLine("3. Writing을 위한 스레드 부분 실행!!!");
            while (!Start_Service)
            {
                string message = Console.ReadLine();
                m_writer.WriteLine("[" + nickname + "]" + message);
                m_writer.Flush();
            }

        }
        public static void Main(string[] args)
        {
            string[] temp = new string[100];
            temp[0] = "127.0.0.1";
            temp[1] = "8234";
            temp[2] = "haha";

            new ChatClient(temp[0], Int32.Parse(temp[1]), temp[2]);//ChatClient 생성
        }
    }
}
