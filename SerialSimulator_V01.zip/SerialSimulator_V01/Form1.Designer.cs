﻿namespace SerialSimulator_V01
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_comport = new System.Windows.Forms.ComboBox();
            this.listBox_msgbox = new System.Windows.Forms.ListBox();
            this.button_operate = new System.Windows.Forms.Button();
            this.button_msgclear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.button_msgclear);
            this.splitContainer1.Panel1.Controls.Add(this.button_operate);
            this.splitContainer1.Panel1.Controls.Add(this.comboBox_comport);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.listBox_msgbox);
            this.splitContainer1.Size = new System.Drawing.Size(800, 450);
            this.splitContainer1.SplitterDistance = 181;
            this.splitContainer1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "통신포트";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox_comport
            // 
            this.comboBox_comport.Dock = System.Windows.Forms.DockStyle.Top;
            this.comboBox_comport.FormattingEnabled = true;
            this.comboBox_comport.Location = new System.Drawing.Point(0, 23);
            this.comboBox_comport.Name = "comboBox_comport";
            this.comboBox_comport.Size = new System.Drawing.Size(181, 20);
            this.comboBox_comport.TabIndex = 1;
            this.comboBox_comport.SelectedIndexChanged += new System.EventHandler(this.comboBox_comport_SelectedIndexChanged);
            this.comboBox_comport.MouseClick += new System.Windows.Forms.MouseEventHandler(this.comboBox_comport_MouseClick);
            // 
            // listBox_msgbox
            // 
            this.listBox_msgbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox_msgbox.FormattingEnabled = true;
            this.listBox_msgbox.ItemHeight = 12;
            this.listBox_msgbox.Location = new System.Drawing.Point(0, 0);
            this.listBox_msgbox.Name = "listBox_msgbox";
            this.listBox_msgbox.Size = new System.Drawing.Size(615, 450);
            this.listBox_msgbox.TabIndex = 0;
            // 
            // button_operate
            // 
            this.button_operate.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_operate.Location = new System.Drawing.Point(0, 43);
            this.button_operate.Name = "button_operate";
            this.button_operate.Size = new System.Drawing.Size(181, 43);
            this.button_operate.TabIndex = 2;
            this.button_operate.Text = "동작";
            this.button_operate.UseVisualStyleBackColor = true;
            this.button_operate.Click += new System.EventHandler(this.button_operate_Click);
            // 
            // button_msgclear
            // 
            this.button_msgclear.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_msgclear.Location = new System.Drawing.Point(0, 86);
            this.button_msgclear.Name = "button_msgclear";
            this.button_msgclear.Size = new System.Drawing.Size(181, 43);
            this.button_msgclear.TabIndex = 3;
            this.button_msgclear.Text = "메시지 클리어";
            this.button_msgclear.UseVisualStyleBackColor = true;
            this.button_msgclear.Click += new System.EventHandler(this.button_msgclear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ComboBox comboBox_comport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox_msgbox;
        private System.Windows.Forms.Button button_operate;
        private System.Windows.Forms.Button button_msgclear;
    }
}

