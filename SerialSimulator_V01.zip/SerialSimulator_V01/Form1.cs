﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// 추가코드
using System.IO;
using System.IO.Ports;

namespace SerialSimulator_V01
{
    public partial class Form1 : Form
    {
        SerialPort my_serial = new SerialPort();                        // 토리얼 통신 포트 설정을 위한 변수 선언

        string recv_data_str = null;                                    // 시리얼 통신으로 수신된 데이터를 저장하는 변수

        delegate void SetTextCallBack(string str);                      // 화면에 값을 표시하기 위한 callback 함수

        // 윈도우 창 생성될 때 실행되는 함수
        public Form1()
        {
            InitializeComponent();
                                                                        // 시리얼 통신 수신 인터럽트를 등록하는 함수
            my_serial.DataReceived += new SerialDataReceivedEventHandler(serial_DataReceived);
        }

        // 컴퓨터에서 사용가능한 통신포트 검색 함수 : 콤보박스를 클릭하면 검색됨
        private void comboBox_comport_MouseClick(object sender, MouseEventArgs e)
        {
            comboBox_comport.Items.Clear();                             // 콤보박스의 아이템을 클리어함
            foreach(string comport in SerialPort.GetPortNames())
            {
                comboBox_comport.Items.Add(comport);                    // 검색된 아이템을 콤보박스 아이템에 추가함
            }
        }

        // 검색된 통신포트 열기 함수
        private void comboBox_comport_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(!my_serial.IsOpen)                                       // 기존 시리얼 통신포트가 열려 있는 지 검사
            {
                try
                {
                    my_serial.PortName = comboBox_comport.Text;         // 선택된 통신포트 Name 설정
                    my_serial.BaudRate = 9600;                          // 통신속도를 9600bps로 설정
                    my_serial.Open();                                   // 통신포트 열기
                    listBox_msgbox.Items.Add(comboBox_comport.Text + " Is Opened !!");
                                                                        // 메시지 리스트박스에 메시지 출력
                }
                catch
                {
                    listBox_msgbox.Items.Add(comboBox_comport.Text + " can't open !!");
                }
            }
        }

        // 수신메시지 리스트박스 클리어
        private void button_msgclear_Click(object sender, EventArgs e)
        {
            listBox_msgbox.Items.Clear();                               // 메시지 리스트 박스 아이템 클리어
        }

        // 시리얼 통신 수신 인터럽트가 발생되었을 동작하는 함수
        private void serial_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int i_recv_size = my_serial.BytesToRead;                    // 수신된 데이터 크기 저장
            byte[] b_tmp_buf = new byte[i_recv_size];                   // 저장하기 위한 버퍼 생성

            my_serial.Read(b_tmp_buf, 0, i_recv_size);                  // 데이터를 읽어서 버퍼에 저장

            recv_data_str += Encoding.Default.GetString(b_tmp_buf);     // 수신된 byte 데이터를 string 데이터로 변환(ASCII 코드)

            if (b_tmp_buf[i_recv_size - 1] == '\r')                     // 수신된 데이터의 마지막 데이터 검사 : '\r' 검색
            {
                string cmd = GenRespCodeForCmd(recv_data_str);          // 수신된 명령 분석 후 응답 처리 명령 받은

                this.BeginInvoke(new SetTextCallBack(display_data), new object[] { recv_data_str });
                                                                        // 수신된 명령을 메시지 리스트박스에 표시                
                this.BeginInvoke(new SetTextCallBack(display_data), new object[] { cmd });
                                                                        // 전송할 명령을 메시지 리스트박스에 표시

                my_serial.Write(cmd);                                   // 선택한 데이터를 전송
                recv_data_str = null;                                   // 수신된 데이터 저장 변수 초기화
            }
        }

        // 전송된 명령에 대한 응답 코드 작성 함수
        private string GenRespCodeForCmd(string str_data)
        {
            string result = null;
            switch(str_data)
            {
                case "W1\r":
                    result = "Name1=TaeSan    TaeSan  TaeSan  TaeSan  TaeSan  TaeSan  TaeSan  TaeSan  TaeSan  TaeSan\r\n";
                    break;
                case "W2\r":
                    result = "Name2=TaeSan    TaeSan  TaeSan  TaeSan  TaeSan  TaeSan  TaeSan  TaeSan  TaeSan  TaeSan\r\n";
                    break;
                case "STATUS\r":
                    result = "status-0200-0567-0200-0600+0100-0900101004700001\r\n";
                    break;
                case "K\r":
                    result = "\r\nModel name=TaeSan  \r\n";
                    break;
                case "MODEL\r":
                    result = "Model=01\r\n";
                    break;
                case "G\r":
                    result = "G-096.0+000.0+000.010047.000+000.00101000000\r\n";
                    break;
            }
            return result;
        }

        // 시리얼 통신 수신 인터럽트에서 화면에 데이터를 표시하는 함수
        private void display_data(string str)
        {
            this.listBox_msgbox.Items.Add(str);
        }

        private void button_operate_Click(object sender, EventArgs e)
        {

        }
    }
}
